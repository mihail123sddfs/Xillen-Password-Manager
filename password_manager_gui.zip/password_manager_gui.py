#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Deadly's Password Manager (GUI)
GUI менеджер паролей с шифрованием AES-256 (Fernet), мастер-паролем, поиском и копированием в буфер обмена.
Автор: Deadly
"""

import os
import json
import base64
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from typing import Dict, Any

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
except Exception as e:
    raise SystemExit("Требуется пакет 'cryptography'. Установите: pip install cryptography")

def _get_data_dir() -> str:
    try:
        # Предпочтительно: локальная папка пользователя (Windows/macOS/Linux)
        if os.name == 'nt':
            base = os.getenv('LOCALAPPDATA') or os.path.expanduser('~')
            data_dir = os.path.join(base, 'DeadlyPasswordManager')
        else:
            data_dir = os.path.join(os.path.expanduser('~'), '.deadly_password_manager')
        os.makedirs(data_dir, exist_ok=True)
        # Проверяем доступ на запись
        test_path = os.path.join(data_dir, '.write_test')
        with open(test_path, 'w', encoding='utf-8') as f:
            f.write('ok')
        os.remove(test_path)
        return data_dir
    except Exception:
        # Фолбэк: текущая директория (если доступна на запись)
        try:
            test_path = os.path.join(os.getcwd(), '.write_test')
            with open(test_path, 'w', encoding='utf-8') as f:
                f.write('ok')
            os.remove(test_path)
            return os.getcwd()
        except Exception:
            # Последний фолбэк: домашняя директория
            data_dir = os.path.expanduser('~')
            os.makedirs(data_dir, exist_ok=True)
            return data_dir

DATA_DIR = _get_data_dir()
DATA_FILE = os.path.join(DATA_DIR, "passwords.json")
SALT_FILE = os.path.join(DATA_DIR, "salt.key")

# -------------------------- Crypto Core --------------------------
class SecureStorage:
    def __init__(self):
        self.key: bytes | None = None

    def _derive_key(self, password: str, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100_000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def set_master_password(self, password: str) -> bool:
        # Создаем/читаем соль
        if os.path.exists(SALT_FILE):
            with open(SALT_FILE, 'rb') as f:
                salt = f.read()
        else:
            salt = os.urandom(16)
            with open(SALT_FILE, 'wb') as f:
                f.write(salt)

        self.key = self._derive_key(password, salt)

        # Валидируем ключ на существующей базе (если есть)
        if os.path.exists(DATA_FILE):
            try:
                self._load_data()
                return True
            except Exception:
                return False
        return True

    def _cipher(self) -> Fernet:
        if not self.key:
            raise RuntimeError("Ключ не инициализирован")
        return Fernet(self.key)

    def _load_data(self) -> Dict[str, Any]:
        if not os.path.exists(DATA_FILE):
            return {}
        with open(DATA_FILE, 'rb') as f:
            enc = f.read()
        fernet = self._cipher()
        raw = fernet.decrypt(enc)
        return json.loads(raw.decode('utf-8'))

    def _save_data(self, data: Dict[str, Any]) -> None:
        fernet = self._cipher()
        enc = fernet.encrypt(json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8'))
        with open(DATA_FILE, 'wb') as f:
            f.write(enc)

    # Public helpers
    def list_services(self) -> list[str]:
        data = self._load_data()
        return sorted(list(data.keys()))

    def get_entry(self, service: str) -> Dict[str, str] | None:
        return self._load_data().get(service)

    def upsert_entry(self, service: str, username: str, password: str) -> None:
        data = self._load_data()
        data[service] = {"username": username, "password": password}
        self._save_data(data)

    def delete_entry(self, service: str) -> None:
        data = self._load_data()
        if service in data:
            del data[service]
            self._save_data(data)

# -------------------------- UI --------------------------
class PasswordManagerGUI:
    def __init__(self):
        self.sec = SecureStorage()
        self.root = tk.Tk()
        self.root.title("🔐 Deadly's Password Manager")
        self.root.geometry("900x560")
        self.root.configure(bg="#0f1320")
        self.root.minsize(820, 520)

        # Accent colors
        self.color_accent = "#00ff88"
        self.color_panel = "#0b0f1a"
        self.color_text_muted = "#9aa4b2"

        self._apply_style()
        self._build_login()

    # ---- Styles ----
    def _apply_style(self):
        style = ttk.Style()
        style.theme_use('default')
        style.configure("TFrame", background=self.color_panel)
        style.configure("Treeview",
                        background=self.color_panel,
                        fieldbackground=self.color_panel,
                        foreground="white",
                        borderwidth=0)
        style.map('Treeview', background=[('selected', '#16324b')])
        style.configure("TButton", padding=6)

    # ---- Login Screen ----
    def _build_login(self):
        self.login_frame = tk.Frame(self.root, bg="#0f1320")
        self.login_frame.pack(fill=tk.BOTH, expand=True)

        title = tk.Label(self.login_frame, text="Менеджер паролей", font=("Arial", 24, "bold"), fg=self.color_accent, bg="#0f1320")
        title.pack(pady=20)

        card = tk.Frame(self.login_frame, bg=self.color_panel, highlightthickness=1, highlightbackground="#1c2236")
        card.pack(pady=10, ipadx=20, ipady=20)

        info = tk.Label(card, text="Введите мастер‑пароль", fg="white", bg=self.color_panel)
        info.grid(row=0, column=0, columnspan=2, pady=(10, 6))

        tk.Label(card, text="Мастер‑пароль:", fg=self.color_text_muted, bg=self.color_panel).grid(row=1, column=0, sticky='e', padx=6)
        self.password_entry = tk.Entry(card, show='*', bg="#10182a", fg="white", relief=tk.FLAT, insertbackground="white", width=28)
        self.password_entry.grid(row=1, column=1, pady=6)
        self.password_entry.focus_set()

        reveal = tk.Button(card, text="Показать", command=self._toggle_pwd, bg="#1c2236", fg="#c9d1d9")
        reveal.grid(row=2, column=0, sticky='e', padx=6, pady=(6, 10))
        login = tk.Button(card, text="Войти", command=self._login, bg=self.color_accent, fg="#00131a", font=("Arial", 11, 'bold'))
        login.grid(row=2, column=1, sticky='w', pady=(6, 10))

        self.login_frame.bind_all('<Return>', lambda e: self._login())

    def _toggle_pwd(self):
        if self.password_entry.cget('show') == '*':
            self.password_entry.config(show='')
        else:
            self.password_entry.config(show='*')

    def _login(self):
        pwd = self.password_entry.get().strip()
        if not pwd:
            messagebox.showwarning("Ошибка", "Введите мастер‑пароль")
            return
        ok = self.sec.set_master_password(pwd)
        if not ok:
            messagebox.showerror("Ошибка", "Неверный мастер‑пароль")
            return
        # Success → open main UI
        self.login_frame.destroy()
        self._build_main()

    # ---- Main UI ----
    def _build_main(self):
        topbar = tk.Frame(self.root, bg="#0f1320")
        topbar.pack(fill=tk.X, padx=16, pady=8)

        tk.Label(topbar, text="Поиск:", fg="white", bg="#0f1320").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        search = tk.Entry(topbar, textvariable=self.search_var, bg="#10182a", fg="white", relief=tk.FLAT, insertbackground="white", width=32)
        search.pack(side=tk.LEFT, padx=8)
        tk.Button(topbar, text="Найти", command=self._filter, bg="#1c2236", fg="#c9d1d9").pack(side=tk.LEFT)

        tk.Button(topbar, text="➕ Добавить", command=self._add_entry_dialog, bg=self.color_accent, fg="#00131a", font=("Arial", 10, 'bold')).pack(side=tk.LEFT, padx=8)
        tk.Button(topbar, text="✏️ Редактировать", command=self._edit_selected, bg="#1c2236", fg="#c9d1d9").pack(side=tk.LEFT)
        tk.Button(topbar, text="🗑️ Удалить", command=self._delete_selected, bg="#ef4444", fg="white").pack(side=tk.LEFT, padx=8)

        self.status = tk.Label(self.root, text="Готов", fg=self.color_text_muted, bg="#0f1320")
        self.status.pack(fill=tk.X, padx=16)

        # Tree (list)
        self.tree = ttk.Treeview(self.root, columns=("service", "username"), show='headings', height=16)
        self.tree.heading("service", text="Сервис")
        self.tree.heading("username", text="Логин")
        self.tree.column("service", width=260)
        self.tree.column("username", width=260)
        self.tree.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)

        # Bottom buttons
        bottom = tk.Frame(self.root, bg="#0f1320")
        bottom.pack(fill=tk.X, padx=16, pady=(0, 12))
        tk.Button(bottom, text="👁️ Показать пароль", command=self._show_password, bg="#1c2236", fg="#c9d1d9").pack(side=tk.LEFT)
        tk.Button(bottom, text="📋 Копировать логин", command=self._copy_username, bg="#1c2236", fg="#c9d1d9").pack(side=tk.LEFT, padx=8)
        tk.Button(bottom, text="📋 Копировать пароль", command=self._copy_password, bg="#1c2236", fg="#c9d1d9").pack(side=tk.LEFT)

        self._refresh()

        # Double-click to edit
        self.tree.bind('<Double-1>', lambda e: self._edit_selected())

    # ---- Helpers ----
    def _refresh(self, filtered: list[str] | None = None):
        for i in self.tree.get_children():
            self.tree.delete(i)
        services = filtered if filtered is not None else self.sec.list_services()
        for s in services:
            entry = self.sec.get_entry(s) or {}
            self.tree.insert('', 'end', values=(s, entry.get('username', '')))
        self.status.config(text=f"Всего записей: {len(services)}")

    def _filter(self):
        q = (self.search_var.get() or '').strip().lower()
        if not q:
            self._refresh()
            return
        matched = [s for s in self.sec.list_services() if q in s.lower()]
        self._refresh(matched)

    def _selected_service(self) -> str | None:
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Выбор", "Выберите запись")
            return None
        vals = self.tree.item(sel[0], 'values')
        return vals[0] if vals else None

    def _add_entry_dialog(self):
        self._entry_dialog(title="Добавить запись")

    def _edit_selected(self):
        service = self._selected_service()
        if not service:
            return
        entry = self.sec.get_entry(service) or {"username": "", "password": ""}
        self._entry_dialog(title="Редактировать запись", service=service, username=entry.get('username', ''), password=entry.get('password', ''))

    def _entry_dialog(self, title: str, service: str = "", username: str = "", password: str = ""):
        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.configure(bg=self.color_panel)
        dlg.geometry("420x220")
        dlg.grab_set()

        tk.Label(dlg, text="Сервис:", fg="white", bg=self.color_panel).grid(row=0, column=0, sticky='e', padx=8, pady=(16,6))
        tk.Label(dlg, text="Логин:", fg="white", bg=self.color_panel).grid(row=1, column=0, sticky='e', padx=8, pady=6)
        tk.Label(dlg, text="Пароль:", fg="white", bg=self.color_panel).grid(row=2, column=0, sticky='e', padx=8, pady=6)

        service_var = tk.StringVar(value=service)
        user_var = tk.StringVar(value=username)
        pass_var = tk.StringVar(value=password)

        e1 = tk.Entry(dlg, textvariable=service_var, bg="#10182a", fg="white", relief=tk.FLAT, insertbackground="white", width=30)
        e2 = tk.Entry(dlg, textvariable=user_var, bg="#10182a", fg="white", relief=tk.FLAT, insertbackground="white", width=30)
        e3 = tk.Entry(dlg, textvariable=pass_var, bg="#10182a", fg="white", relief=tk.FLAT, insertbackground="white", width=30)
        e1.grid(row=0, column=1, pady=(16,6))
        e2.grid(row=1, column=1, pady=6)
        e3.grid(row=2, column=1, pady=6)

        def save():
            s = service_var.get().strip()
            u = user_var.get().strip()
            p = pass_var.get().strip()
            if not s:
                messagebox.showwarning("Ошибка", "Введите название сервиса")
                return
            self.sec.upsert_entry(s, u, p)
            self._refresh()
            dlg.destroy()

        tk.Button(dlg, text="Сохранить", command=save, bg=self.color_accent, fg="#00131a", font=("Arial", 10, 'bold')).grid(row=3, column=1, sticky='w', pady=12)
        tk.Button(dlg, text="Отмена", command=dlg.destroy, bg="#1c2236", fg="#c9d1d9").grid(row=3, column=0, sticky='e', pady=12)

    def _delete_selected(self):
        service = self._selected_service()
        if not service:
            return
        if messagebox.askyesno("Удалить", f"Удалить запись '{service}'?"):
            self.sec.delete_entry(service)
            self._refresh()

    def _show_password(self):
        service = self._selected_service()
        if not service:
            return
        entry = self.sec.get_entry(service)
        if not entry:
            messagebox.showerror("Ошибка", "Запись не найдена")
            return
        messagebox.showinfo("Пароль", f"Сервис: {service}\nЛогин: {entry.get('username','')}\nПароль: {entry.get('password','')}")

    def _copy_username(self):
        service = self._selected_service()
        if not service:
            return
        entry = self.sec.get_entry(service)
        if not entry:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(entry.get('username', ''))
        self.status.config(text="Логин скопирован в буфер обмена")

    def _copy_password(self):
        service = self._selected_service()
        if not service:
            return
        entry = self.sec.get_entry(service)
        if not entry:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(entry.get('password', ''))
        self.status.config(text="Пароль скопирован в буфер обмена")

    def run(self):
        self.root.mainloop()

# -------------------------- main --------------------------
if __name__ == "__main__":
    PasswordManagerGUI().run()
